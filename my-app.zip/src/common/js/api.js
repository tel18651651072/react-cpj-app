/**
 * Created by mac on 2018/1/1.
 */

import axios from 'axios'
import qs from 'qs'
const baseUrl = 'http://localhost:8124'

// axios.defaults.withCredentials = true
export function IdentifyGetCode() {
    return axios.get(baseUrl+'/ccap',{withCredentials: true})
        .catch(function (error) {
            console.log(error)
        })
}

export function IdentifypostCode(code) {
    return axios.post(baseUrl+'/IdentifyCode',{
        code:code
    },{withCredentials: true})
        .catch(function (error) {
            console.log(error)
        })
}

export function register(token) {
    return axios.post(baseUrl+'/register',{token:token},{withCredentials: true})
        .catch(function (error) {
            console.log(error)
        })
}

export function submitUserdata(userdata) {
    return axios.post(baseUrl+'/submitUserData',qs.stringify({userdata:userdata}))
        .catch(err => {
            console.log(err)
        })
}

export function verifyEmail(email) {
    return axios.post(baseUrl+'/verifyEmail',{email:email})
        .catch(err => {
            console.log(err)
        })
}

export function verifyLogin(userdata) {
    return axios.post(baseUrl+'/verifyLogin',{userdata:userdata})
        .catch(err => {
            console.log(err)
        })
}

export function modifyInfo(userdata) {
    return axios.post(baseUrl+'/modifyInfo',{userdata:userdata})
        .catch(err => {
            console.log(err)
        })
}

export function emailTestPost(userdata) {
    return axios.post(baseUrl+'/emailTest',qs.stringify({userdata:userdata})).catch(function (error) {
        console.log(error)
    })
}

export function submitContent(contentData) {
    return axios.post(baseUrl+'/submitContent',qs.stringify({contentData:contentData}))
        .catch(err => {
            console.log(err)
        })
}

export function fetchContent(classify) {
    return axios.post(baseUrl+'/fetchContent',{classify:classify})
        .catch(err => {
            console.log(err)
        })
}

export function searchResult(searchData) {
    return axios.post(baseUrl+'/searchResult',qs.stringify({searchData:searchData}))
        .catch(err => {
            console.log(err)
        })
}

export function fetchDetail(uidcode) {
    return axios.post(baseUrl+'/fetchDetail',qs.stringify({uidcode:uidcode}))
        .catch(err => {
            console.log(err)
        })
}

export function getSkimnum(pageInfo) {
    // axios.defaults.withCredentials = true
    return axios.post(baseUrl+'/getSkim',qs.stringify({pageInfo:pageInfo}),{withCredentials: true})
        .catch(err => {
            console.log(err)
        })
}
// 测试
// export function getSkimnum() {
//     // axios.defaults.withCredentials = true
//     return axios.post(baseUrl+'/getSkim')
//         .catch(err => {
//             console.log(err)
//         })
// }
