/**
 * Created by mac on 2018/1/10.
 */

import { observable, action,runInAction } from "mobx";

 class SuccessState {
       @observable loginSuccess = 0;
       @observable registerSuccess = 0;
       @observable loginSubmitTip = '';
       @observable modalClass ='';
       @observable editorSuccess =0;
       @observable searchData = '';
       @observable searchSuccess =0;
       @action changeLoginState() {
           this.loginSuccess = 1
           this.loginSubmitTip = '登录成功'
       }
       @action changeRegisterState() {
           this.registerSuccess = 1
       }
       @action changeModalClas(value) {
           this.modalClass = value
       }
       @action changeEditorState() {
           this.editorSuccess = 1
       }
       @action searchDataState(searchData) {
           this.searchData = searchData;
           this.searchSuccess =1
       }

 }
export default new SuccessState()