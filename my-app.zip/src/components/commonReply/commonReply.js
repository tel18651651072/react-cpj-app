/**
 * Created by mac on 2018/1/24.
 */
import React, {Component} from 'react';
import './Style.css';
// import NavbarBanner from './../../components/navbarBanner/NavbarBanner'
// import {Link} from 'react-router-dom';

class CommonReply extends Component {
    constructor(props) {
        super(props);
    }

    render() {
        return (
            <div className="commonContent-wrapper">
                <div className="commonContent-container">
                    <div className="contentList">
                        <ul>
                            {
                                this.props.replyList.length?this.props.contentList.map((item, index)=>
                                    <li className="contentLi" key={index}>
                                        <div className="author"><label>{item.author?item.author:'无名英雄'}</label>发表于：<label>{item.create_time}</label></div>
                                        <div dangerouslySetInnerHTML={{__html: escape(item.content)}}></div>
                                        <ul><span>相关类别：</span>{
                                            item.classify.split(',').map((item,index) =>
                                                <li className="classifyList" key={index}>{item}</li>
                                            )
                                        }</ul>
                                    </li>
                                ):'目前还没有回复哦～'
                            }
                        </ul>
                    </div>
                    <div className="relatedList">相关列表内容</div>
                </div>
            </div>
        )
    }
}
CommonReply.defaultProps = {
    replyList:[]
}
export default CommonReply
