/**
 * Created by mac on 2017/12/24.
 */

import React, {Component} from 'react';
import './Style.css';
import PropTypes from 'prop-types';

class Login extends Component {
    constructor() {
        super();
        this.state={
            count:0
        }
    }

    render() {
        return (
            <div className="Login-wrapper" onClick={sessionStorage.getItem('email')?null:this.props.loginClick}>
                {sessionStorage.getItem('email')?sessionStorage.getItem('email')+"你好":"登录/注册"}
                <br/><span onClick={this.leaveClick.bind(this)}>{sessionStorage.getItem('email')?'退出':''}</span>
            </div>
        )
    }

    leaveClick(e) {
        console.log(e.target.nodeName.toLowerCase())
        if (e.target.nodeName.toLowerCase()==='span') {
            sessionStorage.removeItem('email')
            e.stopPropagation();
            this.setState({
                count:1
            })
        } else {
            return
        }
    }
}

Login.propTypes = {
    loginClick:PropTypes.func
}

export default Login