/**
 * Created by mac on 2018/1/17.
 */
import React, {Component} from 'react';
import './Style.css';
import {fetchDetail,getSkimnum} from './../../common/js/api'
import {escape} from './../../common/js/escape'
import {getCanvasCode} from './../../common/js/getCanvasCode'
import CommonReply from './../../components/commonReply/commonReply'
import E from 'wangeditor'

class Detail extends Component {
    constructor(props) {
        super(props);
        this.state = {
            article:[]
        }
    }

    componentWillMount() {
        console.log(document.location.href)
        var url = document.location.href;
        console.log(getCanvasCode(url))
        let ifAddSkimNum = false
        var uid = this.props.match.params.uid;
        var canvascode = getCanvasCode(url)
        var pageInfo = {
            uid:uid,
            canvascode:canvascode
        }
        getSkimnum(pageInfo).then(response => {
            console.log(response)
        })
        // 测试
        // getSkimnum().then(response => {
        //     console.log(response)
        // })
        fetchDetail(uid).then(response => {
            console.log(response.data)
            this.setState({
                article:response.data
            })
        })
    }

    componentDidMount() {
        const elem = this.refs.editorElem
        const editor = new E(elem)
        // 使用 onchange 函数监听内容的变化，并实时更新到 state 中
        editor.customConfig.onchange = html => {
            this.setState({
                editorContent: html
            })
        }
        editor.customConfig.zIndex = 100;
        editor.create()
    }
    componentWillUpdate() {
    }

    render() {
        return (
            <div className="detail-wrapper">
                <div className="content-part">
                    <div className="detail-content">
                        {
                            this.state.article.length?this.state.article.map((item,index) =>
                                <li key={index} className="detailLi">
                                    <h3 className="articleTitle">{item.headerline}</h3>
                                    <div className="assistantPart">
                                        <span className="author">{item.author}</span>
                                        <span className="time">{item.create_time}</span>
                                    </div>
                                    <div dangerouslySetInnerHTML={{__html: escape(item.content)}}></div>
                                    <div className="foot">
                                        <span className="skimnum">阅读量：{item.skimnum}</span>
                                        <span className="replynum">评论</span>
                                    </div>
                                </li>
                            ):'还没有相关数据，敬请期待'
                        }
                    </div>
                    <div className="function-part">
                        <span className="btn-item">关注问题</span>
                        <span className="btn-item">我要回答</span>
                    </div>
                </div>
                <div className="container">
                    <CommonReply/>
                    <div className="editor-box">
                        {/* 将生成编辑器 */}
                        <div ref="editorElem" style={{textAlign: 'left',zIndex:10}}>
                        </div>
                        <div className="foot">
                            <span className="submitBtn">提交</span>
                        </div>
                    </div>
                </div>
            </div>
        )
    }
}

export default Detail
