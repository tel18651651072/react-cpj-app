/**
 * Created by mac on 2018/1/24.
 */
var mysql      = require('mysql');
var db = require('./../config/db');


var replySql = 'insert '
exports.reply = function (app) {
    app.post('/reply',function (req,res) {
        db.query()
    })
}
