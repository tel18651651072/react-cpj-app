/**
 * Created by mac on 2018/1/9.
 */
var mysql      = require('mysql');
var db = require('./../config/db');

var  sql = 'select count(*) from cpj.user where email=? and password=? LIMIT 1';

exports.verifyLogin = function (app,session) {
    app.post('/verifyLogin',function (req, res, next) {
        console.log(req.body.userdata)
        db.query(sql,req.body.userdata,function (err,result) {
            if (err) {
                console.log(err);
                res.render('无')
            }
            console.log(result)
            if (result[0]['count(*)']>0) {
                res.json({flag:true,message:'登录成功'})
            } else {
                res.json({flag:false,message:'密码错误'})
            }
        })
    })
}
